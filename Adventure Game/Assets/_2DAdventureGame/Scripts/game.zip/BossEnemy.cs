using System;
using UnityEngine;
using static UnityEditor.Searcher.SearcherWindow.Alignment;

public class BossEnemy : MonoBehaviour
{
    public float speed = 3.0f; // SPEED
    public Rigidbody2D enemyRB; // RB

    bool vertical; // Move Direction

    // Move Timer
    public float changeTime = 3.0f;
    float timer;
    int direction = 1;
    //-------------------------

    //Health and Fixing
    public int maxHealth = 10;
    public int health { get { return currentHealth; } }
    public int currentHealth;

    bool broken = true;
    public bool isBroken { get { return broken; } }
    public event Action OnFixed;

    // particles
    public ParticleSystem smokeParticleEffect;

    // projectile
    public GameObject projectilePrefab;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        enemyRB = GetComponent<Rigidbody2D>();
        currentHealth = maxHealth;
        timer = changeTime;
    }

    // Update is called once per frame
    void Update() {
        timer -= Time.deltaTime;

        if (timer < 0) {
            direction = -direction;
            timer = changeTime;
        }

        // create a function that uses a timer to shoot projectiles
        // the shooting time is a random time within a set range
        /*
         if (shootTimer < 0) {
            Shoot();
         }
         */
        
    }

    private void FixedUpdate() {
        if (!broken) {
            return;
        }

        Vector2 position = enemyRB.position;
        if (!vertical) {
            position.x = position.x + speed * direction * Time.deltaTime;

        } else {
            position.y = position.y + speed * direction * Time.deltaTime;
        }
        enemyRB.MovePosition(position);
    }

    private void OnTriggerEnter2D(Collider2D other) {
        PlayerController player = other.gameObject.GetComponent<PlayerController>();

        if (player != null) {
            player.ChangeHealth(-1);
        }
    }

    public void Fix() {
        broken = false;
        enemyRB.simulated = false;
        smokeParticleEffect.Stop();
        OnFixed?.Invoke();
    }

    public void Shot() {
        //broken = true;
        //enemyRB.simulated = false;
        //smokeParticleEffect.Stop();
        //OnFixed?.Invoke();
        currentHealth -= 1;
    }
}
