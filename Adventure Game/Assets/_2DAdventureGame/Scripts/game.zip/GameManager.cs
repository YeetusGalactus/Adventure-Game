using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

    public PlayerController player;
    EnemyController[] enemies;
    BossEnemy boss;
    public UIHandler uiHandler;

    int enemiesFixed = 0;
    bool bossFixed = false;

    
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        enemies = FindObjectsByType<EnemyController>(FindObjectsSortMode.None);
        boss = FindAnyObjectByType<BossEnemy>();

        foreach (var enemy in enemies) {
            enemy.OnFixed += HandleEnemyFixed;
        }

        boss.OnFixed += HandleBossFixed;

        uiHandler.SetCounter(0, enemies.Length);
        uiHandler.SetBossCheck(bossFixed);

        player.OnTalkedToNPC += HandlePlayerTalkedToNPC;
    }

    // Update is called once per frame
    void Update()
    {
        if (player.health <= 0) {
            uiHandler.DisplayLoseScreen();
            Invoke(nameof(ReloadScene), 3f);
        }

        //if (AllEnemiesFixed()) {
        //    uiHandler.DisplayWinScreen();
        //    Invoke(nameof(ReloadScene), 3f);
        //}
    }

    void ReloadScene() {
        SceneManager.LoadScene("MainScene");
    }

    bool AllEnemiesFixed() {
        foreach (EnemyController enemy in enemies) {
            if (enemy.isBroken) return false;
        }
        return true;
    }

    bool BossFixed() {
        if (boss.isBroken) return false;
        return true;
    }

    void HandleEnemyFixed() {
        enemiesFixed++;
        uiHandler.SetCounter(enemiesFixed, enemies.Length);
    }

    void HandleBossFixed() {
        bossFixed = true;
        uiHandler.SetBossCheck(bossFixed);
    }

    void HandlePlayerTalkedToNPC() {
        if (AllEnemiesFixed()) {
            //uiHandler.DisplayWinScreen();
            // Add a new uidocument to display boss fight dialogue
            //Invoke(nameof(ReloadScene), 3f);
            uiHandler.DisplayBossDialogue();
            
        } else if (AllEnemiesFixed() && BossFixed()) {
            uiHandler.DisplayWinScreen();
            Invoke(nameof(ReloadScene), 3f);
        } else {
            uiHandler.DisplayDialogue();
        }
    }

}
