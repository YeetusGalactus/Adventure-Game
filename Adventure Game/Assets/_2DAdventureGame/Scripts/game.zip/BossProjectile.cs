using UnityEngine;

public class BossProjectile : MonoBehaviour
{

    Rigidbody2D Rigidbody2d;

    void Awake() {
        Rigidbody2d = GetComponent<Rigidbody2D>();

    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.magnitude > 100.0f) {
            Destroy(gameObject);
        }
    }

    public void Launch(float force) {
        Rigidbody2d.AddForce(Vector2.down * force);
    }

    private void OnTriggerEnter2D(Collider2D other) {
        PlayerController player = other.GetComponent<PlayerController>();

        if (player != null) {
            player.ChangeHealth(-1);
        }
        Destroy(gameObject);
    }

    private void OnCollisionEnter2D(Collision2D collision) {
        Destroy(gameObject);
    }

}
